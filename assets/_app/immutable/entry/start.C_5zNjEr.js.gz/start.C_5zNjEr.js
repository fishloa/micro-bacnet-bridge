import{l as o,a as r}from"../chunks/maYFDmxo.js";export{o as load_css,r as start};
