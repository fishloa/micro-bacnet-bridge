import{l as o,a as r}from"../chunks/BK9O47Hg.js";export{o as load_css,r as start};
