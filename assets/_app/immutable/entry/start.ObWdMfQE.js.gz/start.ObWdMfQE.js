import{l as o,a as r}from"../chunks/Dbos3XuT.js";export{o as load_css,r as start};
